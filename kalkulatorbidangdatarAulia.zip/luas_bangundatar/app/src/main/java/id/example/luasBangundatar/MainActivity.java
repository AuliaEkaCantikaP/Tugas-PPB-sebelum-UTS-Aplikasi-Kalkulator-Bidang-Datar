package id.example.luasBangundatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText ed1, ed2;
    TextView tvLuas, tvKel;
    Button persegi, segitiga, lingkaran;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        persegi = findViewById(R.id.btnPersegi);
        segitiga = findViewById(R.id.btnSegitiga);
        lingkaran = findViewById(R.id.btnLingkaran);
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        tvLuas = findViewById(R.id.textLuas);
        tvKel = findViewById(R.id.textKeliling);

        persegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double panjang = Double.parseDouble(ed1.getText().toString());
                double lebar = Double.parseDouble(ed2.getText().toString());

                double keliling = 2*(panjang + lebar);
                double luas = panjang*lebar;
                tvKel.setText(String.format("Keliling : %.2f", keliling));
                tvLuas.setText(String.format("Luas : %.2f", luas));
            }
        });

        lingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double diameter = Double.parseDouble(ed1.getText().toString());

                double keliling = 3.14*diameter;
                double luas = 0.25*3.14*diameter;
                tvKel.setText(String.format("Keliling : %.2f", keliling));
                tvLuas.setText(String.format("Luas : %.2f", luas));
            }
        });

        segitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double alas = Double.parseDouble(ed1.getText().toString());
                double tinggi = Double.parseDouble(ed2.getText().toString());

                double keliling = alas*3;
                double luas = 0.5*alas*tinggi;
                tvKel.setText(String.format("Keliling : %.2f", keliling));
                tvLuas.setText(String.format("Luas : %.2f", luas));
            }
        });

    }
}